<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 3
      h1 Contenidos digitales y técnicas de posicionamiento
    
    .d-flex.flex-wrap.mb-5.align-items-center
      img.mb-4.mb-lg-auto.col-lg-4.mx-auto(src="@/assets/curso/temas/tema3/img-1.png" style="max-width: 400px")
      .col-lg-8.ps-lg-4
        p Desde inicios del siglo XX el marketing se convirtió en uno de los principales motores para acelerar y contribuir al crecimiento de las empresas. El marketing tradicional, como es conocido, permitía a las organizaciones divulgar la información sobre sus productos y servicios de forma masiva por medio de vallas publicitarias, prensa, televisión y radio; la ventaja de estas estrategias se basa en que estos medios se encuentran en todas partes y han sido siempre de fácil acceso para la población, es por esto que se lograba tener un gran alcance e impacto. Sin embargo, este tipo de estrategias estaban enfocadas únicamente en la promoción del producto, en destacar sus características y beneficios, sin dar lugar al usuario o consumidor, además de que estas campañas requieren grandes inversiones y sus resultados no son fáciles de medir para definir cuál es en realidad la efectividad y el retorno que generan las inversiones. Para dar solución a estos aspectos, desde 1990 surgió el concepto de marketing digital, un nuevo tipo de estrategias completamente innovadoras y digitales, basadas en el internet y las herramientas tecnológicas.

        p.mb-0 Esta nueva forma de implementar el marketing se ha vuelto fundamental para las empresas en la actualidad, ya que permite crear un mayor relacionamiento con los clientes, se enfoca conocerlos y brindarles mejores experiencias durante todo el proceso de compra, esto hace que aumenten las interacciones y que sean los mismos clientes quienes se acerquen a las empresas. Otra de las ventajas que ofrece el marketing digital para las empresas es que les permite evolucionar constantemente, además de que los costos no son tan altos como en el marketing tradicional y los resultados se pueden medir con mayor facilidad.
    
    .d-flex.flex-wrap.align-items-center.mb-5
      .col-lg-9.order-2.order-mlg1.pe-md-4
        p Para implementar campañas exitosas de marketing digital, es fundamental elegir correctamente el contenido, para esto es muy importante hacerlo basado en el conocimiento de los clientes, ya no es suficiente solo definir el público objetivo, sino que se debe hacer un análisis más profundo a través de la realización del perfil del buyer persona, que permite conocer con más detalle a los consumidores. Cuando las empresas conocen a sus clientes están en la capacidad de implementar campañas mucho más enfocadas y con mejores resultados, brindando a los espectadores el contenido de su interés, con interacciones continuas y creando relaciones más cercanas.
        p.mb-0 Otro de los factores que contribuyen al éxito de las campañas de marketing digital son las estrategias de posicionamiento, que pueden ser pagas o no. Entre estas se encuentran las estrategias SEO y SEM, que buscan aumentar el tráfico en los sitios web de las empresas, posicionándose en los primeros lugares en los resultados de los motores de búsqueda, para esto se implementan también algunas técnicas como los factores HTML, keywords, fichas temáticas y normalización de datos. 
      img.mb-4.mb-md-auto.mx-auto.col-lg-3.order-1.order-lg-2(src="@/assets/curso/temas/tema3/img-2.png" style="max-width: 295px")

    Separador
    .titulo-segundo.color-acento-contenido
      h2#t_3_1 3.1. Elección y publicación de contenidos
    
    p.mb-5 Elegir correctamente el contenido que comparten las organizaciones resulta clave para alcanzar objetivos del marketing digital y generar campañas exitosas, para ello es necesario realizar este proceso de forma estratégica y por medio del análisis de datos que garanticen un alto impacto en la audiencia. Este proceso comprende las siguientes fases:
    
    .content-card.mb-5
      .col-12.col-lg.pe-lg-3.d-flex
        .card-edit-row
          p.mb-0.text-center Investigación
      .col-12.col-lg.pe-lg-3.d-flex
        .card-edit-row
          p.mb-0.text-center Ideación y planificación
      .col-12.col-lg.pe-lg-3.d-flex
        .card-edit-row
          p.mb-0.text-center Creación de contenido y optimización
      .col-12.col-lg.pe-lg-3.d-flex
        .card-edit-row
          p.mb-0.text-center Distribución de contenido
      .col-12.col-lg.d-flex
        .card-edit-row.card-edit-row--last
          p.mb-0.text-center Análisis de resusltados

    p.mb-5 Ahora se desglosará este proceso para su mayor comprensión, esto es:

    .d-flex.mb-5
      h3.d-flex.align-items-center.py-2.ps-3.pe-4(style="background-color: #FF5A20; border-radius: 50px")
        p.mb-0.me-4(style="width: 36px; height: 36px; border-radius: 50%; border: 5px solid white;")
        |Investigación
      
    .d-flex.flex-wrap.mb-5.align-items-center
      .col-lg-9.pe-lg-4.order-2.order-lg-1
        p Esta fase permite conocer el mercado en el cual se encuentra la empresa, la competencia, las fortalezas y debilidades que se tienen como organización y el público objetivo al cual se pretende alcanzar. <b>Esta información es la base para definir adecuadamente los canales por los cuales se distribuirá la información, el formato, el estilo, el tono y los temas que va a abarcar el contenido.</b>
        p.mb-0 El objetivo principal es definir de manera clara y precisa el perfil que representa al cliente, para poder construir este perfil es necesario definir información demográfica, objetivos y motivaciones, los problemas que enfrenta en su día a día, sus hábitos de consumo, sus intereses, su perfil profesional y que medios prefiere para recibir información.
      img.mb-4.mb-lg-auto.col-lg-3.order-1.order-lg-2.mx-auto(src="@/assets/curso/temas/tema3/img-3.png" style="max-width: 295px")

    .d-flex.mb-5
      h3.d-flex.align-items-center.py-2.ps-3.pe-4(style="background-color: #FF5A20; border-radius: 50px")
        p.mb-0.me-4(style="width: 36px; height: 36px; border-radius: 50%; border: 5px solid white;")
        |Ideación y planeación
    
    p.mb-5 En esta fase se establecen los objetivos de la estrategia de generación de contenido y se planifican las acciones a desarrollar. Para establecer estos objetivos a alcanzar es necesario emplear la metodología SMART, que consiste en crear objetivos específicos, medibles, alcanzables, realistas y que tengan un tiempo asignado. De esta forma se tiene claro lo que se pretende lograr, algunos de los objetivos más importantes son:

    .container-cards--hover
      .conatiner-card-hover.col-lg.mx-2
        img(src="@/assets/curso/temas/tema3/card-1.svg" style="max-width: 105px")
        p.mb-0.p-4 Aumentar el reconocimiento de marca
      .conatiner-card-hover.col-lg.mx-2
        img(src="@/assets/curso/temas/tema3/card-2.svg" style="max-width: 105px")
        p.mb-0.p-4 Generar tráfico de calidad
      .conatiner-card-hover.col-lg.mx-2
        img(src="@/assets/curso/temas/tema3/card-3.svg" style="max-width: 105px")
        p.mb-0.p-4 Generar <em>leads</em>
      .conatiner-card-hover.col-lg.mx-2
        img(src="@/assets/curso/temas/tema3/card-4.svg" style="max-width: 105px")
        p.mb-0.p-4 Aumentar el retorno a la inversión
      .conatiner-card-hover.col-lg.mx-2
        img(src="@/assets/curso/temas/tema3/card-5.svg" style="max-width: 105px")
        p.mb-0.p-4 Fidelizar a los clientes

    p.mb-5 Planear las acciones consiste en determinar las tareas específicas que se deben desarrollar para el cumplimiento de los objetivos. Por ejemplo, si uno de los objetivos que se plantea es aumentar el reconocimiento de marca, para esto se deben realizar acciones como definir el responsable, definir el público al que va dirigido, crear la plantilla del correo con un diseño llamativo, definir el contenido y definir fecha y hora del envío.

    .d-flex.mb-5
      h3.d-flex.align-items-center.py-2.ps-3.pe-4(style="background-color: #FF5A20; border-radius: 50px")
        p.mb-0.me-4(style="width: 36px; height: 36px; border-radius: 50%; border: 5px solid white;")
        |Creación de contenido y optimización
    
    p.mb-5 En esta fase es necesario recordar que el contenido debe estar centrado en las necesidades e intereses de los consumidores, y no directamente en las necesidades de la empresa. Los formatos más usados para la generación de contenido son los siguientes:

    SlyderF.mb-5(columnas="col-lg-6 col-xl-4")
      .tarjeta.mx-auto(style="background-color: #E1D6F3; overflow: hidden; max-width: 400px")
        img(src="@/assets/curso/temas/tema3/img-4.png")
        p.p-4.mb-0 <b>Textos:</b> se centra en brindar información que ayude a la audiencia a resolver sus problemas y está orientado a conseguir leads más calificados, algunos de los formatos que se encuentran de este tipo son: <em>blogs</em>, <em>ebooks</em>,  listas, entre otros.
      .tarjeta.mx-auto(style="background-color: #E1D6F3; overflow: hidden; max-width: 400px")
        img(src="@/assets/curso/temas/tema3/img-5.png")
        p.p-4.mb-0 <b>Imágenes:</b> es uno de los contenidos más utilizados especialmente en redes sociales,  es más visual y atractivo para la audiencia y suele expresar el mensaje que se quiere transmitir de forma concisa y atractiva, algunos de estos formatos son: infografías, gifs, fotografías, etc.
      .tarjeta.mx-auto(style="background-color: #E1D6F3; overflow: hidden; max-width: 400px")
        img(src="@/assets/curso/temas/tema3/img-6.png")
        p.p-4.mb-0 <b>Videos:</b> es el contenido preferido por los usuarios, se recomienda realizarlos en formatos cortos para asegurar que sean vistos hasta el final y también subtitularlos, de modo que puedan ser vistos sin sonido, algunos de los formatos de vídeo más usados son: entrevistas, webinars, transmisión en vivo, entre otros.
      .tarjeta.mx-auto(style="background-color: #E1D6F3; overflow: hidden; max-width: 400px")
        img(src="@/assets/curso/temas/tema3/img-7.png")
        p.p-4.mb-0 <B>Audios:</b> este tipo de contenido puede ser escuchado en cualquier momento y lugar, entre los formatos más usados están: canciones, <b>podcast</b> y audiolibros.
      .tarjeta.mx-auto(style="background-color: #E1D6F3; overflow: hidden; max-width: 400px")
        img(src="@/assets/curso/temas/tema3/img-8.png")
        p.p-4.mb-0 <b>Contenido interactivo:</b> puede combinar uno o varios de los formatos mencionados, este tipo de contenido permite mejorar la visibilidad, aumentar la interacción e involucrar activamente a los consumidores.
    
    .d-flex.mb-5
      h3.d-flex.align-items-center.py-2.ps-3.pe-4(style="background-color: #FF5A20; border-radius: 50px")
        p.mb-0.me-4(style="width: 36px; height: 36px; border-radius: 50%; border: 5px solid white;")
        |Distribución de contenido
      
    .d-flex.flex-wrap.align-items-center.mb-5
      img.mb-4.mb-lg-auto.col-lg-3.mx-auto(src="@/assets/curso/temas/tema3/img-9.png" style="max-width: 295px")
      .col-lg-9.ps-lg-4
        p Consiste en seleccionar los canales por medio de los cuales se va a difundir el contenido creado, <b>puede ser por medio de redes sociales, página web, emails, eventos, asociaciones con otras marcas relacionadas, influencers, entre otros.</b> El canal de distribución del contenido también debe elegirse en base a las preferencias del buyer persona, de modo que se garantice que los canales seleccionados sean efectivamente los que prefieren los consumidores.
    
    .d-flex.mb-5
      h3.d-flex.align-items-center.py-2.ps-3.pe-4(style="background-color: #FF5A20; border-radius: 50px")
        p.mb-0.me-4(style="width: 36px; height: 36px; border-radius: 50%; border: 5px solid white;")
        |Análisis de los resultados
    
    p.mb-5 Esta fase es fundamental para determinar el éxito o el fracaso de la estrategia implementada, gracias a las analíticas que arrojan diversas plataformas es posible identificar el alcance que se logra, los puntos de mejora en las estrategias y realizar correcciones a tiempo en caso de no tener los resultados esperados.

    Separador
    .titulo-segundo.color-acento-contenido
      h2#t_3_2 3.2. Técnicas y criterios de publicación
          
    p.mb-5 Para realizar la publicación de contenido de forma ordenada, clara y efectiva es necesario conocer algunas técnicas y criterios que contribuyen a que las publicaciones tengan el impacto que se pretende generar en la audiencia y a que la creación de contenido de valor se realice de forma adecuada. Es fundamental tener en cuenta que los contenidos no pueden ser difundidos de cualquier forma por medio de los canales digitales, ya que de ser así este no tendría los resultados esperados y no se podría garantizar el éxito en el cumplimiento de los objetivos que se tienen al crear el contenido de valor. Es necesario que para realizar las publicaciones y el contenido de forma efectiva se cumpla con los siguientes criterios:
        
    .d-flex.flex-wrap.mb-5
      TabsA.color-acento-contenido.col-lg-9.pe-lg-4
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Equipo capacitado y <br>creativo")
          p.mb-0 Personal idóneo, con personas responsables de la creación de la estrategia, de la creación del contenido, del diseño gráfico y un <em>community manager</em>, que se encargue de gestionar el contenido en los canales digitales; si bien no es obligatorio contar con una persona diferente para cada una de estas labores, sí es importante que estas tareas sean desarrolladas en su totalidad.
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Frecuencia de publicación")
          p.mb-0 Deben realizarse de forma regular y frecuente, con contenido de calidad y actualizada para que la audiencia pueda acceder de forma habitual. También es importante crear contenido en base a las fechas especiales que estén relacionadas con temas de interés para la empresa y en las que puedan tener lugar los productos o servicios ofertados. 
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Coherencia en línea de<br> publicaciones")
          p.mb-0 Las publicaciones que se realicen deben tener relación y coherencia, es importante que manejen la misma línea temática que esté relacionada con la línea de negocios que se tiene, de esta forma la audiencia la asimilará con claridad y la relacionará con la marca.
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Horarios de publicación")
          p.mb-0 Aplica especialmente para las redes sociales, se deben seleccionar cuidadosamente los horarios en que se realizan las publicaciones, de forma que sean hechas en los periodos en que hay mayor tráfico en la red, para alcanzar el mayor alcance posible.
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Características del <br>contenido y descripciones")
          p.mb-0 Seleccionar las fuentes que se van a usar, validar y verificar la información que se comparte, usar palabras sencillas, generar una relación de cercanía y empatía con los clientes, presentar los productos o servicios de forma sutil, no realizar publicaciones demasiado largas o imágenes con mucho texto, ser actualizado en base a los nuevos intereses y tendencias que siga el buyer persona. 
        .tarjeta.p-4(style="background-color: #FFE6DD" titulo="Crear un calendario de <br>publicaciones")
          p.mb-0 Los calendarios de publicaciones se realizan con la finalidad de programar todas las publicaciones que se deben realizar para completar la estrategia de <em>marketing</em> digital, es necesario programar todas las publicaciones al menos con un mes de anticipación, de esta forma se asegura la frecuencia de publicaciones y que se realicen en los tiempos establecidos.
      img.d-none.d-lg-flex.mb-auto.col-lg-3.mx-auto(src="@/assets/curso/temas/tema3/img-9.svg" style="max-width: 295px")
    
    Separador
    .titulo-segundo.color-acento-contenido
      h2#t_3_3 3.3. Indexación de contenidos según estrategias SEO y SEM
    
    p.mb-5 SEO y SEM son estrategias de posicionamiento que buscan alcanzar una mayor visibilidad en los motores de búsqueda, de modo que se logre que la página web aparezca en los primeros lugares en los resultados de las búsquedas. La diferencia fundamental entre estas dos estrategias es que, para lograr dicho posicionamiento, el SEO es de forma orgánica y el SEM es de forma paga. A continuación, se profundiza al respecto de cada una de estas estrategias:

    .row
      .col-md-6.col-xl.mb-4.mb-xl-0.d-flex
        .w-100.tarjeta-numerada.color-primario.p-5
          .tarjeta-numerada__numero
            .h2 1
          p
            b Estrategias SEM
          p El SEM (<em>Search Engine Marketing</em>), que en español hace referencia al <em>marketing</em> de motores de búsqueda, consiste en la elaboración de campañas y anuncios para los cuales se paga con el fin de que aparezcan de forma prioritaria en los motores de búsqueda, de esta manera se aumenta su visibilidad y accesibilidad. Otra de las ventajas de esta estrategia es que permite llegar a un público que tenga intereses similares a los que ofrece la empresa a través de su campaña.

      .col-md-6.col-xl.mb-4.mb-xl-0.d-flex
        .w-100.tarjeta-numerada.color-acento-contenido.p-5
          .tarjeta-numerada__numero
            .h2(style="color: white") 2
          p
            b Estrategias SEO
          p SEO (<em>Search Engine Optimization</em>), hace referencia a la optimización para motores de búsqueda, su objetivo es aparecer en los primeros resultados de las búsquedas de manera orgánica, es decir sin tener que pagar a los programas de motores de búsqueda. Esta estrategia se basa en la creación de contenido de alto valor, principalmente en WordPress, para la redacción de blogs; redacción de <em>posts</em> para redes; ubicación de palabras clave en comentarios de redes sociales; y la creación de <em>hashtags</em> en redes con publicaciones asociadas a las principales tendencias del momento.
    
    Separador
    .titulo-segundo.color-acento-contenido
      h2#t_3_4 3.4. Técnicas de posicionamiento
    
    p.mb-5 Las técnicas de posicionamiento permiten optimizar las páginas web y el contenido generado de modo que los motores de búsqueda, evidencien en los resultados, las búsquedas relacionadas de forma prioritaria, es decir, en la parte superior de los resultados. A continuación, se presentan algunas técnicas de posicionamiento web, las cuales son factores HTML, <em>keywords</em> o palabras clave, fichas temáticas y propuesta gramatical, esto es:
    
    AcordionA(tipo="a" clase-tarjeta="tarjeta tarjeta-edit-acordeon")
      .row.col-lg-11.mx-auto(titulo="Factores HTML")
        img.mb-4.mb-md-auto(src='@/assets/curso/temas/tema3/img-10.svg' style="max-width: 133px" alt='imagen decorativa')
        .col-md.ps-lg-4
          p El código HTML consiste en la estructura que tiene el contenido de una página web, ya sea el texto, las listas, las imágenes, los videos, etc, por medio de esta estructura se definen los títulos, párrafos y en general todo el contenido de la página. Los factores HTML hacen parte de las técnicas de posicionamiento, ya que estructurar y optimizar correctamente los elementos de la página web permite que los motores de búsqueda identifiquen y utilicen estas etiquetas para incluir el contenido en los resultados de las búsquedas. Un ejemplo de esto es la etiqueta de título que se pone en el código HTML de un sitio, y que es tomada por el buscador de Google para incluir dicho título de la página fácilmente en los resultados de búsqueda.
      .row.col-lg-11.mx-auto(titulo="<em>Keywords</em>")
        img.mb-4.mb-md-auto(src='@/assets/curso/temas/tema3/img-11.svg' style="max-width: 133px" alt='imagen decorativa')
        .col-md.ps-lg-4
          p Son las palabras claves que se eligen en los sitios web para posicionar y aumentar el tráfico en el sitio, ya que es en base a las palabras clave que los motores de búsqueda presentan los resultados. Para seleccionarlas es necesario identificar dentro del contenido del sitio web las palabras que tengan mayor cantidad de búsquedas. Las <em>keywords</em> pueden ser genéricas, cuando constan de una o dos palabras; semi-genéricas cuando se componen de entre 3 y 5 palabras; y por último las <em>long tail keywords</em>, que superan las 5 palabras. Es en base a las <em>keywords</em> que se optimizan los principales motores de búsqueda, por eso resulta tan importante elegirlas correctamente.
          p En base al ciclo de compra del cliente, las palabras claves se pueden clasificar en:
          ul.lista-ul
            li.mb-4
              i.fas.fa-check(style="color: #6936C1")
              | <b>Keywords informativas:</b> generan grandes cantidades de búsquedas.
            li.mb-4
              i.fas.fa-check(style="color: #6936C1")
              | <b>Palabras clave transaccionales:</b> palabras claves buscadas en el momento en que los clientes potenciales se encuentran haciendo una selección de alternativas.
            li.mb-4
              i.fas.fa-check(style="color: #6936C1")
              | <b>Palabras clave comerciales:</b> dirigidas a clientes potenciales que están a punto de tomar la decisión de compra.
      .row.col-lg-11.mx-auto(titulo="Fichas Técnicas")
        img.mb-4.mb-md-auto(src='@/assets/curso/temas/tema3/img-12.svg' style="max-width: 133px" alt='imagen decorativa')
        .col-md.ps-lg-4
          p Son herramientas que resumen y presentan los aspectos principales del contenido de publicaciones digitales, permite sintetizar la información de mejor manera, de modo que sea más fácil consultarla. Las fichas temáticas incluyen aspectos como el número de la ficha, keywords, temática, breve descripción del contenido, entre otros.
      .row.col-lg-11.mx-auto(titulo="Propuesta Gramatical")
        img.mb-4.mb-md-auto(src='@/assets/curso/temas/tema3/img-13.svg' style="max-width: 133px" alt='imagen decorativa')
        .col-md.ps-lg-4
          p La propuesta gramatical abarca las técnicas de meta tags y de etiquetas dinámicas como las que se mencionan a continuación:
          ul.lista-ul
            li.mb-4
              i.fas.fa-check(style="color: #6936C1")
              | <b>Técnicas de meta tags:</b> hacen parte de los documentos HTML y brindan información a los motores de búsqueda con respecto a los aspectos claves de la página web, como título, descripción y keywords. Los meta tags de keywords incluyen palabras claves que le indican al buscador el contenido general o la temática del sitio web.
            li.mb-4
              i.fas.fa-check(style="color: #6936C1")
              | <b>Etiquetas dinámicas:</b> son aquellas que integran herramientas externas para registrar la actividad que tiene un sitio web, permite enviar notificaciones cada vez que se produce una conversión en el sitio. Este tipo de etiquetas son muy útiles principalmente para el marketing de afiliación, que está basado y en el que se paga por el número de conversiones que se generen en la página.
      .row.col-lg-11.mx-auto(titulo="Normalización de datos")
        img.mb-4.mb-md-auto(src='@/assets/curso/temas/tema3/img-14.svg' style="max-width: 133px" alt='imagen decorativa')
        .col-md.ps-lg-4
          p Consiste en organizar los metadatos en base a una serie de normas o reglas, si bien no existe un modelo internacional de metadatos, existen unas normas internacionales elaboradas por la ISO/IEC, que se encarga de normalizar los elementos de datos y facilitar el intercambio de información. El modelo más conocido para la normalización de metadatos es el de Dublin Core.
 
          p.mb-0 Los metadatos referentes al tipo de contenido están relacionados con el título, tema, descripción, fuente, lenguaje, relación con otros metadatos y lugar geográfico. Los metadatos referentes a la propiedad intelectual incluyen el autor, editor, otros colaboradores y los derechos de autor. Los metadatos referentes a la identificación, temporalidad y formato incluyen la fecha de publicación, el tipo, el formato y el identificador. Esta información se compila en su totalidad en una tabla que agrupa los 3 tipos de información de los metadatos en columnas.
    
    Separador
    .titulo-segundo.color-acento-contenido
      h2#t_3_5 3.5. Reglamento de seguridad e higiene industrial para publicación de contenidos
    
    .d-flex.flex-wrap.mb-5.align-items-center
      img.mb-4.mb-lg-auto.col-lg-4.mx-auto(src="@/assets/curso/temas/tema3/img-15.png" style="max-width: 400px")
      .col-lg-8.ps-lg-4
        p Los reglamentos de Seguridad e Higiene Industrial son documentos técnicos, exigidos por la ley colombiana en el marco del Sistema General de Riesgos Laborales y la implementación de los sistemas de Gestión de la Seguridad y la Salud en el trabajo. Estos reglamentos deben ser realizados por las empresas dependiendo el sector en que se encuentren, en ellos se determinan los lineamientos de seguridad que se deben seguir, en base al sector, para la protección de los colaboradores, a través de la prevención y mitigación de riesgos laborales. 

        p.mb-0 Estos reglamentos tienen relación con las campañas de <em>marketing</em> digital ya que es necesario que en todas las publicaciones realizadas para promocionar los productos, servicios o lugares de la empresa se evidencie el cumplimiento de las normas de seguridad establecidas en los reglamentos estipulados para el sector. Por ejemplo, para el sector de restaurantes y servicios de alimentación, durante la crisis de pandemia por la COVID-19, el Gobierno Nacional impuso lineamientos adicionales para la manipulación y venta de alimentos, que debían ser incluidos y acatados en los reglamentos de seguridad e higiene industrial. Entre estos lineamientos se encuentra el garantizar la protección permanente de los alimentos que sean exhibidos, usando películas plásticas, papel aluminio o cualquier tipo de empaque; respetar al máximo la capacidad prevista para la atención a clientes, evitando grandes concentraciones y aglomeraciones; y adicionalmente la medida del uso obligatorio del tapabocas para todas las personas, entre muchos otros.

    .d-flex.flex-wrap
      .col-md-7.col-lg-9.col-xl-10.order-2.order-md-1.pe-md-4
        p Por lo anterior, es necesario conocer estos reglamentos porque su cumplimiento debe verse reflejado en las campañas o en el contenido digital que sea publicado por los restaurantes, es decir que no puede difundirse contenido en el que se incumpla con estas normas, por ejemplo, subir a las redes sociales del establecimiento fotos de los alimentos que sean exhibidos sin ningún tipo de empaque, imágenes en las que se presenten meseros, cocineros, cajeros o cualquier otro colaborador del restaurante sin el uso adecuado del tapabocas, o publicar contenido para promocionar grandes eventos, que por la contingencia estaban prohibidos.
        p.mb-0 De esta forma, cada sector debe garantizar el cumplimiento de sus debidos reglamentos, y esto debe evidenciarse siempre en el contenido y en las campañas de <em>marketing</em> digital que implemente la empresa, sin importar el formato o el canal por el que sea difundido dicho contenido.
      img.mb-4.mb-md-auto.mx-auto.col-md-5.col-lg-3.col-xl-2.order-1.order-md-2(src="@/assets/curso/temas/tema3/img-16.svg" style="max-width: 185px" alt="imagen decorativa")        

</template>

<script>
import SlyderF from '@/components/SlyderF.vue'
import TabsA from '@/components/TabsA.vue'
export default {
  name: 'Tema3',
  components: { SlyderF, TabsA },
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass">
.content-card
  display: flex
  flex-wrap: wrap
  .card-edit-row
    background-color: #232997
    border-radius: 10px
    width: 100%
    padding: 1rem 1.5rem
    display: flex
    align-items: center
    justify-content: center
    position: relative
    max-width: 300px
    &--last::after
      display: none
    &::after
      content: url(../assets/curso/temas/tema3/decorador-card.svg)
      position: absolute
      z-index: 2
      right: -2.1rem
      top: 50%
      transform: translateY(-50%)
    p
      color: white
      font-weight: bold
  @media (max-width: 991px)
    .card-edit-row
      margin: auto
      margin-bottom: 1rem
      &::after
        display: none
.container-cards--hover
  display: flex
  flex-wrap: wrap
  justify-content: center
  padding-top: 60px
  .conatiner-card-hover
    position: relative
    background-color: #B39AE0
    max-width: 226px
    min-width: 226px
    display: flex
    flex-wrap: wrap
    justify-content: center
    text-align: center
    transition: all .2s linear
    margin-bottom: 125px
    &::after
      content: ''
      position: absolute
      bottom: -50px
      width: 0
      height: 0
      background: transparent
      border-top: 50px solid #B39AE0
      border-right: 113px solid transparent
      border-left: 113px solid transparent
      transition: all .2s linear
    img
      margin-top: -60px
    p
      width: 100%
      color: black
      font-weight: bold
      transition: all .2s linear
    &:hover
      background-color: #6936C1
      &::after
        border-top: 50px solid #6936C1
      p
        color: white
</style>
