module.exports = 'Social media, investigación y creación de contenidos'
